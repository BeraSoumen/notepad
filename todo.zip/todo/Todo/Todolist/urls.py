from django.urls import path
from Todolist import views

urlpatterns = [
     path('',views.my_todo,name='home'),
]


# Create your views here.

from django.shortcuts import render

# Create your views here.
def my_todo(request):
    if request.method == 'POST':

               text = request.POST['txt']
               
               context = {'text' : text}
               return render(request, 'home.html', context)
    return render(request, 'home.html')
